# sponsorpage

This template should help get you started developing with TailwindCSS.

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run tailwind
```

 